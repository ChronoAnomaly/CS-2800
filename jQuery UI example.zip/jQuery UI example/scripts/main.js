
		$(document).ready(function() {
			$("#tabs").tabs();
		});

    $(document).ready(function() {
    $("#accordion").accordion(
      { 
        event: "mouseover",
        heightStyle: "full",
        collapsible: false
      });
    });
