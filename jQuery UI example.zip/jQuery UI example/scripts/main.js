
		$(function() {
			$("#tabs").tabs();
		});

    	$(function() {
			$("#accordion").accordion(
				{ 
					//event: "mouseover",
					heightStyle: "content",
					collapsible: true,
					active: false
				});
	    });
