//#1 and #3 (toggle h2 headings blue-black when clicked)
var blue_toggle = true;
$('h2').click(function() {
	if (blue_toggle) {
		$(this).css('color', 'blue');
		blue_toggle = false;
	}
	else {
		$(this).css('color', 'black');
		blue_toggle = true;
	}
});


//#2 change logo on mouse hover
var currentSrc;  //need to define currentSrc outside of function for it to persist
$('header img').hover(
  function() {
		currentSrc = $(this).attr("src"); //get current image source
		$(this).attr('src', 'images/bz.jpg');
	},
	function() {
		$(this).attr('src', currentSrc);
	}
); 


//#4 hide numbered list when it's heading is clicked; un-hide on next click
var list_toggle = true;
$('#list-heading').click(function() {	
	if (list_toggle) {
		$('ol li').hide();
		list_toggle = false;
	}
	else {
		$('ol li').show();
		list_toggle = true;
	}
});


//#5 use current date in footer; change backgroud to yellow; center text
$('footer button').click(function() {
	var d = new Date();
	var month = d.getMonth();
	var day = d.getDate();
	var year = d.getFullYear();
	
  //change month from integer to string
  if (month === 0) {
    month = "January";
  }
  else if (month === 1){
    month = "February";
  }
   else if (month === 2){
    month = "March";
  }
   else if (month === 3){
    month = "April";
  }
   else if (month === 4){
    month = "May";
  }
   else if (month === 5){
    month = "June";
  }
   else if (month === 6){
    month = "July";
  }
   else if (month === 7){
    month = "August";
  }
   else if (month === 8){
    month = "September";
  } else if (month === 9){
    month = "October";
  }
   else if (month === 10){
    month = "November";
  }
   else{
    month = "December";
  }
	$('footer p').text(month + ' ' + day + ', ' + year);
	$('footer p').css('background-color', 'yellow');
	$('footer p').css('text-align', 'center');
});


//#6 change first link and corresponding text to WSU Pilot site
$('a:first').attr("href", "http://pilot.wright.edu");
$('a:first').text('WSU Pilot site');


//#7 remove all but the first link on the page
$('a:not(:first)').remove();


//#8 add a new radio button for pineapple
var newRadioBtn = $('<input type="radio" name="fruit" value="pineapple"/><label for="pineapple">Pineapple</label>');
newRadioBtn.appendTo('#radio_buttons');


//#9 pop-up box for 'Go' button indicating fruit selection
 $('form button').click(function() {
  var chkBtn = $('#radio_buttons input[type="radio"]:checked');
  if (!chkBtn.val()) {
    alert("No selection");
  }
  else {
    alert(chkBtn.val());
  } 
}); 


//#10 add an image next to selected fruit
var imageStr;
$('#radio_buttons input').click(function() {
   var chkBtn = $('#radio_buttons input[type="radio"]:checked');
   imageStr = "images/" + chkBtn.val() + ".jpg";
   if ($('form').next().is('img')) {
     $('form').next().attr('src',imageStr);
   }
   else  {
     $('main').append('<img height="64px" width="64px">');
     $('form').next().attr('src',imageStr);
   }
        
});
 